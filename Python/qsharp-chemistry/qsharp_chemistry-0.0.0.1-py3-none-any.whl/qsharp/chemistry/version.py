# Auto-generated file, do not edit.
##
# version.py: Specifies the version of the qsharp-chemistry package.
##
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
##
__version__ = "0.0.0.1"
_user_agent_extra = ""
